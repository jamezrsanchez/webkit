# Module directory

You can add core modules in this directory, without having to publish them on NPM.

More infos on [http://neyric.github.com/webhookit/docs/custom-modules.html](http://neyric.github.com/webhookit/docs/custom-modules.html)