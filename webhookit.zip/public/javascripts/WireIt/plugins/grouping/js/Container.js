/**
 * Some utility classes to provide grouping in the WiringEditor
 * @module grouping-plugin
 */


/**
 * Add methods to container :
 */


/*setOptions: function() {
	

this.getGrouper = this.options.getGrouper	
	
};


onGroupButton: function(e, args) {
    Event.stopEvent(e);

    this.layer.grouper.toggle(this)
    //TODO: link somehow to editor's group manager?
},

addedToGroup: function() {
    if (YAHOO.lang.isValue(this.ddHandle))
    this.ddHandle.style.backgroundColor = "green";
},

 removedFromGroup: function() {
if (YAHOO.lang.isValue(this.ddHandle))
    this.ddHandle.style.backgroundColor = "";
 },*/