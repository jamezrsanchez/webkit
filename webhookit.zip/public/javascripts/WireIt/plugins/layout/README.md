# WireIt Layout plugin

Requires the 'animations' plugin

## TODO

 - Documentation !!!

 - One-step layouting...