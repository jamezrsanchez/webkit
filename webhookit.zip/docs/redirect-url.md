
## Redirect URL

If one of your module returns a redirect_to output, the run page will redirect to the value of this output

This is especially useful for link clicks notifications



<script type="text/javascript">var disqus_shortname = 'redirect-url';</script>