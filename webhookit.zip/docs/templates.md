# Templates

Each module can have its own template. When run with HTML output, the template will be used instead of the default run page.

    /wirings/:id/edit-template


Templates uses [EJS](http://embeddedjs.com/).

You can also set the content/type.


In the future, we plan to select among pre-formatted template (Google Maps, Exhibit, etc...)
 
Ideal for Mashups !
 
 
 
 
<script type="text/javascript">var disqus_shortname = 'templates';</script>
