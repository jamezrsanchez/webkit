
# Creating plugins for Wordpress

HookPress turns all of your WordPress-internal hooks into webhooks. Possible uses include generating push notifications or using non-PHP web technology
	
<iframe scrolling='no' frameborder='0' width='640' height='350' src='http://www.mefeedia.com/video/23051966&iframe'></iframe>
	
## Installation
	
Install a fresh Wordpress blog somewhere and add the <a href="http://wordpress.org/extend/plugins/hookpress/">HookPress plugin</a>.



<script type="text/javascript">var disqus_shortname = 'tutorial-wordpress';</script>