# Public execution of the wirings

Give access to public users to call it from outside

    /wirings/public/:publicname
    /wirings/public/:publicname.json
    

<script type="text/javascript">var disqus_shortname = 'public-run';</script>