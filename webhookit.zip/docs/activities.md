# Activities


Go to /activities to view the latest runs of your wirings.

You can inspect:

  * the calling parameters
  * the output value
  * time to complete the execution
  * response format
  
  
<script type="text/javascript">var disqus_shortname = 'activities';</script>
